do

function run(msg, matches)
return [[istaraliraq_bot 
An advanced administration bot based on TG-CLI written in Lua



#Developers
@z557z [ Dev ]
@iRaQIiNtV  [ Dev ]

Our channels
@istaraliraq_bot [ Arabic ]


http://telegram.me/istaraliraq_bot

The github <>\ git clone https://github.com/z557z/istaraliraq_bot.git -b supergroups
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"telenew$"
},
run = run 
}
end