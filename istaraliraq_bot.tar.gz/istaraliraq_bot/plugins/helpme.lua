do

function run(msg, matches)
  return [[
💭 هناك نوعان من الاوامر لاضهار الاوامر الاساسيه ارسل 

set

والاضهار الاوامر الثانويه ارسل 


help me

#Developers 

@z557z 
@iRaQIiNtV


 ]]

end

return {
  description = "Shows bot help", 
  -- usage = help2: Shows bot help",
  patterns = {
    "^/help$"
  }, 
  run = run 
}

end