--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY BADR SAMAWA                  ▀▄ ▄▀ 
▀▄ ▄▀     BY BADR SAMAWA (@z557z)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY BADR SAMAWA          ▀▄ ▄▀   
▀▄ ▄▀          Dev  : المطور               ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]

do

function run(msg, matches)
  return '❣t \n❣  #Dev 🕵🔧 : \n❣ #Dev : @z557z \n❣ #Dev_bot @istaraliraq_bot \n❣ #Dev_Channel @IrAqIiNtV
end
return {
  patterns = {
    "^version"
  }, 
  run = run 
}

end